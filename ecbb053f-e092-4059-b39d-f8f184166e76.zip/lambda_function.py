import json
import boto3
import requests
import os
from datetime import datetime, timedelta

# Configurações do Discord Webhook
DISCORD_WEBHOOK_URL = os.environ['DISCORD_WEBHOOK_URL']

# Cliente boto3 para o CloudWatch
cloudwatch = boto3.client('cloudwatch')

def send_discord_notification(message):
    data = {
        "content": message
    }
    response = requests.post(DISCORD_WEBHOOK_URL, json=data)
    if response.status_code != 204:
        raise ValueError(f"Falha ao enviar notificação para o Discord: {response.status_code}, {response.text}")

def lambda_handler(event, context):
#    print("Evento recebido:", json.dumps(event))
    print(event) 
    # Métricas a serem monitoradas
    metrics_to_monitor = [
        'WriteThrottleEvents',
        'ReadThrottleEvents'
    ]
    
    # Nome da tabela DynamoDB a ser monitorada
    table_name = os.environ['TABLE_NAME']
    print(f"Tabela a ser monitorada: {table_name}")
    
    for metric_name in metrics_to_monitor:
        print(f"Verificando métrica: {metric_name}")
        
        response = cloudwatch.get_metric_statistics(
            Namespace='AWS/DynamoDB',
            MetricName=metric_name,
            Dimensions=[
                {
                    'Name': 'TableName',
                    'Value': table_name
                }
            ],
            StartTime=datetime.utcnow() - timedelta(minutes=5),
            EndTime=datetime.utcnow(),
            Period=60,
            Statistics=['Sum']
        )
        
        print(f"Resposta da CloudWatch: {response}")
        
        data_points = response.get('Datapoints', [])
        if data_points:
            for point in data_points:
                print(f"Ponto de dados: {point}")
                if point['Sum'] > 0:
                    message = f"Evento de throttle ({metric_name}) detectado na tabela {table_name} com {int(point['Sum'])} eventos."
                    print(f"Enviando mensagem para o Discord: {message}")
                    try:
                        send_discord_notification(message)
                    except Exception as e:
                        print(f"Erro ao enviar notificação para o Discord: {e}")
                    else:
                        print("Notificação enviada com sucesso.")
                else:
                    print(f"Nenhum evento de throttle detectado para {metric_name}.")
        else:
            print(f"Nenhum ponto de dados encontrado para {metric_name}.")
    
    print("Processo de verificação concluído.")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Notificações enviadas se algum evento de throttle for detectado.')
    }